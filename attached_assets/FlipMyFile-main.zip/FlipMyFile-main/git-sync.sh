#!/usr/bin/env bash

# remove stale lock if present
rm -f .git/index.lock

# fetch and integrate remote changes (rebase for linear history)
git fetch origin
git rebase origin/main

# stage & commit any new changes
git add -A
msg="\${1:-Update: \$(date +'%Y-%m-%d %H:%M')}"
git commit -m "\$msg"

# push back up
git push origin HEAD
